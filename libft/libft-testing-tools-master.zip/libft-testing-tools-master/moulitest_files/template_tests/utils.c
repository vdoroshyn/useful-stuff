/*
** Project wide utility functions goes here
*/
