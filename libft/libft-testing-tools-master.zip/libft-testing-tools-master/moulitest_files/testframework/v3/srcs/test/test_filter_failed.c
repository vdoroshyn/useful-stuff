#include <test.h>

int		test_filter_failed(t_test	*test)
{
	return (test->is_fail);
}
