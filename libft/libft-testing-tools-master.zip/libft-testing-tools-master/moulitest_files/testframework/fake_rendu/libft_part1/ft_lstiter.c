#include <libft.h>
void	ft_lstiter(t_list *lst, void (f)(t_list *elem))
{
	(void)lst;
	(void)f;
}
