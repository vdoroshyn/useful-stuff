#include <libft.h>
void	*ft_memmove(void *dest, const void *src, size_t len)
{
	(void)src;
	(void)len;
	return (dest);
}
