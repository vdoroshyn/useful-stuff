#include <libft.h>
int		ft_isalnum(int c)
{
	(void)(c);
	return (0);
}
