#include <libft.h>
char	*ft_strjoin(char const *s1, char const *s2)
{
	(void)s2;
	return ((char *)s1);
}
