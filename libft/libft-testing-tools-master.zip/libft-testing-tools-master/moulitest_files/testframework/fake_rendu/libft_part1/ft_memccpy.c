#include <libft.h>
#include <string.h>
void	*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	(void)dst;
	(void)src;
	(void)n;
	return (strdup("abc"));
}
