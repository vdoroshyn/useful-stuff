#include <libft.h>
char	*ft_strnew(size_t size)
{
	(void)size;
	return ("");
}
