#include <libft.h>
void	ft_bzero(void *s, size_t n)
{
	(void)(s);
	(void)(n);
}
